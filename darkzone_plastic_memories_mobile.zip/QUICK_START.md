# 🚀 快速开始 - 选择适合你的方式

## 方式一：GitHub Actions自动打包（⭐推荐，最简单）

**无需安装任何软件，全程云端完成！**

1. Fork本项目到GitHub
2. 进入Actions页面 → 点击Run workflow
3. 等待约30分钟
4. 下载生成的APK

📖 详细教程: [GITHUB_GUIDE.md](GITHUB_GUIDE.md)

---

## 方式二：Docker打包（适合有Docker经验的用户）

```bash
# 一键构建
docker-compose up

# 或交互式运行
docker run -it -v $(pwd)/bin:/app/bin darkzone-apk-builder
```

📖 详细教程: [APK_BUILD_GUIDE.md](APK_BUILD_GUIDE.md)

---

## 方式三：本地打包（适合开发者）

### Windows:
```cmd
build_apk.bat
```

### Linux/Mac:
```bash
bash build_apk.sh
```

### 跨平台Python:
```bash
python build_apk.py
```

📖 详细教程: [APK_BUILD_GUIDE.md](APK_BUILD_GUIDE.md)

---

## 方式四：电脑直接运行（无需打包）

```bash
pip install kivy
python main.py
```

---

## 📊 方式对比

| 方式 | 难度 | 耗时 | 需要的环境 | 推荐度 |
|------|------|------|-----------|--------|
| GitHub Actions | ⭐ | 30分钟 | 无（云端） | ⭐⭐⭐⭐⭐ |
| Docker | ⭐⭐ | 30分钟 | Docker | ⭐⭐⭐⭐ |
| 本地脚本 | ⭐⭐⭐ | 30-60分钟 | Python+JDK | ⭐⭐⭐ |
| 直接运行 | ⭐ | 1分钟 | Python | ⭐⭐⭐⭐ |

---

## ❓ 常见问题

**Q: 我没有技术背景，推荐哪种方式？**
A: 强烈推荐方式一（GitHub Actions），只需要注册GitHub账号，点点鼠标就能完成。

**Q: 打包需要多长时间？**
A: 首次约30分钟（下载SDK），后续约5-10分钟。

**Q: 生成的APK能在所有手机上运行吗？**
A: 支持Android 5.0+的绝大多数手机。

**Q: 需要付费吗？**
A: GitHub Actions免费用户每月2000分钟，足够使用。

---

## 📞 需要帮助？

如果遇到问题：
1. 查看 [APK_BUILD_GUIDE.md](APK_BUILD_GUIDE.md) 的故障排除部分
2. 检查GitHub Actions日志
3. 提交Issue到项目仓库

---

**🎮 祝你游戏愉快！**

[app]
title = 暗区突围：可塑性记忆
package.name = darkzone_memories
package.domain = org.darkzone
source.dir = .
source.include_exts = py,png,jpg,kv,atlas,json,ttf,mp3,wav,txt,json,ttf,mp3,wav
version = 1.0
requirements = python3,kivy,pygments
orientation = portrait
fullscreen = 0
android.permissions = INTERNET,WRITE_EXTERNAL_STORAGE
android.api = 33
android.minapi = 21
android.sdk = 33
android.ndk = 25b
android.arch = arm64-v8a
ios.kivy_ios_url = https://github.com/kivy/kivy-ios
ios.ios_deploy_url = https://github.com/phonegap/ios-deploy
ios.codesign.allowed = false
[buildozer]
log_level = 2
warn_on_root = 1

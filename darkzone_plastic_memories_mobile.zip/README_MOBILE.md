# 🎮 暗区突围：可塑性记忆 - 手机端

## 📱 生成APK的4种方式

### 方式一：GitHub Actions自动打包 ⭐⭐⭐⭐⭐ 强烈推荐
**难度**: ⭐ | **耗时**: 30分钟 | **要求**: 只需GitHub账号

**超详细图文教程**: [GITHUB_DETAILED_GUIDE.md](GITHUB_DETAILED_GUIDE.md)

**快速步骤**:
1. 注册 [GitHub](https://github.com) 账号
2. 创建新仓库
3. 上传本项目的所有文件
4. 进入Actions页面 → 点击 **Run workflow**
5. 等待30分钟
6. 在Artifacts或Release页面下载APK

**视频教程脚本**: [VIDEO_SCRIPT.md](VIDEO_SCRIPT.md)

**自动配置脚本**（一键完成上传）:
```bash
bash auto_setup.sh
```

---

### 方式二：Docker打包
```bash
docker-compose up
```

### 方式三：本地脚本
**Windows**: `build_apk.bat`
**Linux/Mac**: `bash build_apk.sh`
**Python**: `python build_apk.py`

### 方式四：手动打包
```bash
pip install buildozer cython kivy
buildozer android debug
```

---

## 📖 详细文档

| 文档 | 说明 |
|------|------|
| [GITHUB_DETAILED_GUIDE.md](GITHUB_DETAILED_GUIDE.md) | ⭐ 超详细GitHub Actions教程 |
| [APK_BUILD_GUIDE.md](APK_BUILD_GUIDE.md) | 本地打包完整指南 |
| [GITHUB_GUIDE.md](GITHUB_GUIDE.md) | GitHub Actions配置说明 |
| [QUICK_START.md](QUICK_START.md) | 快速开始 |
| [VIDEO_SCRIPT.md](VIDEO_SCRIPT.md) | 视频教程脚本 |

---

## 🚀 立即开始

**推荐路径**:
1. 打开 [GITHUB_DETAILED_GUIDE.md](GITHUB_DETAILED_GUIDE.md)
2. 按照步骤操作
3. 30分钟后获得APK！

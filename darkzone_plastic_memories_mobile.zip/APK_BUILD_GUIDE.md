# APK打包完整指南

## 系统要求

- **操作系统**: Windows 10/11 / macOS 12+ / Ubuntu 20.04+
- **Python**: 3.8 - 3.11（推荐3.10）
- **Java**: JDK 17（必需）
- **内存**: 至少4GB（推荐8GB+）
- **磁盘空间**: 至少10GB空闲空间
- **网络**: 稳定的网络连接（需要下载约1GB数据）

## 快速开始

### 方式一：一键脚本（推荐）

#### Linux/Mac:
```bash
cd darkzone_plastic_memories_mobile
bash build_apk.sh
```

#### Windows:
```cmd
cd darkzone_plastic_memories_mobile
build_apk.bat
```

### 方式二：手动打包

#### 步骤1: 安装Python依赖
```bash
pip install buildozer cython kivy
```

#### 步骤2: 安装Java JDK

**Ubuntu/Debian:**
```bash
sudo apt-get update
sudo apt-get install openjdk-17-jdk
```

**macOS:**
```bash
brew install openjdk@17
```

**Windows:**
1. 下载JDK 17: https://www.oracle.com/java/technologies/downloads/
2. 安装并设置环境变量

#### 步骤3: 设置环境变量
```bash
export JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64  # Linux路径示例
export PATH=$JAVA_HOME/bin:$PATH
```

#### 步骤4: 运行打包
```bash
cd darkzone_plastic_memories_mobile
buildozer android debug
```

#### 步骤5: 获取APK
打包完成后，APK文件位于:
```
bin/darkzone_memories-1.0-arm64-v8a_armeabi-v7a-debug.apk
```

## 常见问题

### Q: 打包失败，提示"sdkmanager not found"
**A**: Buildozer会自动下载SDK，但需要网络连接。如果下载失败，可以手动下载:
```bash
# 手动下载Android SDK
mkdir -p ~/.buildozer/android/platform
wget https://dl.google.com/android/repository/commandlinetools-linux-9477386_latest.zip
unzip commandlinetools-linux-9477386_latest.zip -d ~/.buildozer/android/platform/
```

### Q: 打包过程内存不足
**A**: 增加交换空间或关闭其他程序。Linux下可以创建swap文件:
```bash
sudo fallocate -l 4G /swapfile
sudo chmod 600 /swapfile
sudo mkswap /swapfile
sudo swapon /swapfile
```

### Q: 如何减小APK大小？
**A**: 编辑 `buildozer.spec`，修改以下配置:
```ini
android.archs = arm64-v8a  # 只打包64位，减小体积
```

### Q: 如何发布到应用商店？
**A**: 需要生成签名APK:
```bash
# 生成密钥
keytool -genkey -v -keystore mykey.keystore -alias myalias -keyalg RSA -keysize 2048 -validity 10000

# 修改buildozer.spec
# android.signing.keystore = mykey.keystore
# android.signing.alias = myalias

# 打包发布版
buildozer android release
```

## 文件说明

| 文件 | 说明 |
|------|------|
| `main.py` | 游戏主程序 |
| `buildozer.spec` | 打包配置文件 |
| `build_apk.sh` | Linux/Mac一键打包脚本 |
| `build_apk.bat` | Windows一键打包脚本 |
| `requirements.txt` | Python依赖列表 |

## 技术支持

如果遇到问题，可以:
1. 查看完整日志: `buildozer android debug 2>&1 | tee build.log`
2. 访问Kivy官方文档: https://kivy.org/doc/stable/
3. 访问Buildozer文档: https://buildozer.readthedocs.io/

---

**注意**: 首次打包时间较长，请耐心等待。后续打包会快很多（约5-10分钟）。

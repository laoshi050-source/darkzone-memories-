# 📱 GitHub Actions 自动打包APK - 超详细教程

## 🎯 目标
**零基础、零配置、零费用**，只需鼠标点击，30分钟后获得APK文件！

---

## 📋 准备工作（2分钟）

### 1. 注册GitHub账号
1. 打开 https://github.com
2. 点击右上角 **Sign up**
3. 输入邮箱、密码、用户名
4. 验证邮箱（查收邮件点击确认链接）

### 2. 下载项目代码
下载 `darkzone_plastic_memories_mobile.zip` 到电脑桌面

---

## 🚀 开始操作（5分钟）

### 步骤1: 创建GitHub仓库（1分钟）

1. 登录GitHub后，点击右上角 **+** 号 → **New repository**

   ![步骤1](https://i.imgur.com/placeholder1.png)

2. 填写仓库信息：
   - **Repository name**: `darkzone-memories` （或你喜欢的名字）
   - **Description**: `暗区突围：可塑性记忆 - Galgame`
   - 选择 **Public** （免费，任何人可见）
   - ✅ 勾选 **Add a README file**
   - 点击 **Create repository**

   ![步骤2](https://i.imgur.com/placeholder2.png)

---

### 步骤2: 上传代码到GitHub（2分钟）

#### 方法A: 网页上传（最简单，推荐）

1. 进入你刚创建的仓库页面
2. 点击 **Add file** → **Upload files**

   ![步骤3](https://i.imgur.com/placeholder3.png)

3. 解压下载的 `darkzone_plastic_memories_mobile.zip`
4. 将解压后的所有文件拖拽到网页上传区域
   - 包含: `main.py`, `buildozer.spec`, `.github/workflows/` 等

   ![步骤4](https://i.imgur.com/placeholder4.png)

5. 在下方填写提交信息：
   - **Commit changes**: `Initial upload`
   - 点击 **Commit changes**

   ![步骤5](https://i.imgur.com/placeholder5.png)

#### 方法B: 命令行上传（适合有git经验的用户）

```bash
# 1. 解压文件
cd ~/Desktop
unzip darkzone_plastic_memories_mobile.zip
cd darkzone_plastic_memories_mobile

# 2. 初始化git
git init
git add .
git commit -m "Initial commit"

# 3. 连接远程仓库（替换为你的用户名）
git remote add origin https://github.com/你的用户名/darkzone-memories.git

# 4. 推送代码
git branch -M main
git push -u origin main
```

---

### 步骤3: 触发自动打包（1分钟）

1. 在仓库页面，点击顶部的 **Actions** 标签

   ![步骤6](https://i.imgur.com/placeholder6.png)

2. 你会看到 **Build Android APK** 工作流
   - 点击 **Build Android APK**

   ![步骤7](https://i.imgur.com/placeholder7.png)

3. 点击右侧的 **Run workflow** 按钮

   ![步骤8](https://i.imgur.com/placeholder8.png)

4. 在弹出的选项中：
   - **Branch**: 选择 `main`
   - **发布到Release?**: 选择 `true` （这样可以直接在Release页面下载）
   - 点击 **Run workflow**

   ![步骤9](https://i.imgur.com/placeholder9.png)

5. 看到绿色提示 "Workflow run was successfully requested" 即触发成功！

   ![步骤10](https://i.imgur.com/placeholder10.png)

---

## ⏳ 等待打包完成（30分钟）

### 监控打包进度

1. 刷新页面，你会看到正在运行的工作流

   ![步骤11](https://i.imgur.com/placeholder11.png)

2. 点击工作流名称查看详细进度

   ![步骤12](https://i.imgur.com/placeholder12.png)

3. 打包过程分为几个阶段：
   - 🟡 **Set up job** - 准备环境（1分钟）
   - 🟡 **Install dependencies** - 安装依赖（2分钟）
   - 🟡 **Cache Buildozer** - 缓存检查（1分钟）
   - 🔵 **Build APK** - 编译APK（20-30分钟）⚠️ 这是最耗时的步骤
   - 🟡 **Upload APK** - 上传文件（1分钟）

   ![步骤13](https://i.imgur.com/placeholder13.png)

4. 当所有步骤都变成 ✅ 绿色，表示打包成功！

   ![步骤14](https://i.imgur.com/placeholder14.png)

---

## 📥 下载APK文件

### 方式1: 从Artifacts下载（每次构建）

1. 在成功的工作流页面，滚动到最下方的 **Artifacts** 区域

   ![步骤15](https://i.imgur.com/placeholder15.png)

2. 点击 **darkzone-memories-apk** 下载ZIP文件

3. 解压下载的ZIP，里面就是 `.apk` 文件

### 方式2: 从Release下载（推荐，更稳定）

如果你在触发时选择了 `发布到Release: true`：

1. 点击仓库页面的 **Releases** 标签（右侧边栏）

   ![步骤16](https://i.imgur.com/placeholder16.png)

2. 找到最新发布的版本

   ![步骤17](https://i.imgur.com/placeholder17.png)

3. 在 **Assets** 区域下载APK文件

   ![步骤18](https://i.imgur.com/placeholder18.png)

---

## 📱 安装APK到手机

### 方法1: 直接安装（最简单）

1. 将下载的APK文件发送到手机（微信/QQ/邮件/数据线）
2. 在手机上点击APK文件
3. 系统提示"允许安装未知来源应用" → 点击 **允许**
4. 点击 **安装**
5. 安装完成，点击 **打开**

### 方法2: 使用ADB（适合开发者）

```bash
# 连接手机，开启USB调试
adb install darkzone-memories.apk
```

### 方法3: 使用二维码（方便分享）

1. 将APK上传到文件传输服务：
   - 奶牛快传: https://cowtransfer.com
   - 文叔叔: https://wenshushu.cn

2. 获取下载链接

3. 使用二维码生成器：
   - https://cli.im
   - 将下载链接生成二维码

4. 手机扫描二维码直接下载安装

---

## 🎮 开始游戏

安装完成后，在手机桌面找到 **暗区突围可塑性记忆** 图标：

- **点击屏幕**: 推进对话
- **点击选项**: 做出选择
- **点击 ☰**: 打开菜单（保存/读取）

---

## 🔄 后续更新

如果你想修改游戏内容并重新打包：

### 1. 修改代码
1. 在GitHub仓库页面点击 `main.py`
2. 点击右上角的 **✏️ Edit** 按钮
3. 修改剧情文本
4. 点击 **Commit changes...** 保存

### 2. 自动重新打包
- 代码修改后会自动触发新的打包
- 或者手动进入Actions页面点击 **Run workflow**

### 3. 下载新版APK
- 等待30分钟后下载新的APK

---

## ❓ 常见问题解决

### Q1: 打包失败，显示红色 ❌

**可能原因**: 网络问题导致SDK下载失败

**解决方法**:
1. 点击失败的工作流
2. 点击右上角的 **Re-run jobs** → **Re-run all jobs**
3. 等待重新打包

![重试](https://i.imgur.com/placeholder19.png)

---

### Q2: 找不到Artifacts下载按钮

**解决方法**:
1. 确保工作流完全完成（所有步骤绿色 ✅）
2. 刷新页面
3. 滚动到页面最底部

---

### Q3: APK安装失败

**可能原因**: 
- Android版本过低（需要Android 5.0+）
- 未允许未知来源安装

**解决方法**:
1. 检查手机设置 → 安全 → 允许未知来源
2. 确保下载的APK文件完整（重新下载）

---

### Q4: 游戏运行卡顿

**解决方法**:
1. 关闭其他后台应用
2. 降低手机分辨率（设置 → 显示）
3. 在buildozer.spec中优化配置

---

### Q5: 如何修改游戏图标/名称？

**修改名称**:
1. 编辑 `buildozer.spec`
2. 修改 `title = 你的游戏名称`

**修改图标**:
1. 准备512x512像素的PNG图片
2. 命名为 `icon.png`
3. 上传到仓库根目录
4. 在 `buildozer.spec` 中添加：
   ```ini
   icon.filename = %(source.dir)s/icon.png
   ```

---

## 📊 费用说明

| 项目 | 费用 | 说明 |
|------|------|------|
| GitHub账号 | 免费 | 个人账号完全免费 |
| GitHub Actions | 免费 | 每月2000分钟额度 |
| 存储空间 | 免费 | 公共仓库无限空间 |
| APK下载 | 免费 | 无限制 |

**2000分钟够用吗？**
- 每次打包约30分钟
- 每月可打包约60次
- 完全足够使用！

---

## 🎁 进阶技巧

### 自动触发打包
每次推送代码自动打包，无需手动点击：

1. 编辑 `.github/workflows/build-apk.yml`
2. 确保有以下配置：
   ```yaml
   on:
     push:
       branches: [ main ]
   ```
3. 这样每次修改代码并推送，就会自动打包

### 版本号自动递增
在每次构建时自动增加版本号：

1. 编辑 `buildozer.spec`
2. 使用动态版本：
   ```ini
   version = 1.0.${GITHUB_RUN_NUMBER}
   ```

### 同时打包多个架构
支持更多手机型号：

编辑 `buildozer.spec`：
```ini
android.archs = arm64-v8a, armeabi-v7a, x86_64
```

---

## 📞 获取帮助

如果遇到问题：

1. **查看日志**: 点击失败的工作流 → 查看具体错误信息
2. **重新运行**: 点击 **Re-run jobs** 重试
3. **检查配置**: 确认 `buildozer.spec` 格式正确
4. **搜索Issues**: https://github.com/kivy/buildozer/issues

---

## ✅ 检查清单

打包前确认：
- [ ] 已注册GitHub账号
- [ ] 已创建仓库
- [ ] 已上传代码（包含 `.github/workflows/build-apk.yml`）
- [ ] 已触发Actions工作流
- [ ] 等待30分钟
- [ ] 下载APK
- [ ] 安装到手机
- [ ] 开始游戏！

---

## 🎉 完成！

现在你应该已经成功：
1. ✅ 创建GitHub仓库
2. ✅ 上传游戏代码
3. ✅ 触发自动打包
4. ✅ 下载APK文件
5. ✅ 安装到手机
6. ✅ 开始游戏！

**祝你游戏愉快！**

*"时光流转，愿你与珍爱之人再次相逢。"*

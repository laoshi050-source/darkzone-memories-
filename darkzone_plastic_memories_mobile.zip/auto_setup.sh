#!/bin/bash
# ============================================================================
# 自动配置脚本 - 简化GitHub Actions打包流程
# ============================================================================
# 使用方法:
#   1. 下载本脚本到解压后的项目目录
#   2. 运行: bash auto_setup.sh
#   3. 按提示输入GitHub用户名和Token
#   4. 脚本自动完成上传和触发打包
# ============================================================================

echo "🎮 暗区突围：可塑性记忆 - 自动配置工具"
echo "=========================================="
echo ""

# 检查git
if ! command -v git &> /dev/null; then
    echo "❌ 未安装git，请先安装:"
    echo "  Ubuntu: sudo apt-get install git"
    echo "  Mac: brew install git"
    echo "  Windows: 下载 https://git-scm.com/download/win"
    exit 1
fi

# 输入GitHub信息
read -p "请输入GitHub用户名: " username
read -s -p "请输入GitHub Token (从Settings -> Developer settings -> Personal access tokens生成): " token
echo ""
read -p "请输入仓库名称 (默认: darkzone-memories): " reponame
reponame=${reponame:-darkzone-memories}

# 配置git
git config user.email "user@example.com"
git config user.name "$username"

# 初始化仓库
echo ""
echo "📦 初始化仓库..."
git init
git add .
git commit -m "Initial commit"

# 添加远程仓库
echo "🔗 连接远程仓库..."
git remote add origin https://$username:$token@github.com/$username/$reponame.git

# 推送代码
echo "⬆️  上传代码..."
git branch -M main
git push -u origin main

if [ $? -eq 0 ]; then
    echo ""
    echo "✅ 代码上传成功！"
    echo ""
    echo "🚀 接下来:"
    echo "  1. 访问 https://github.com/$username/$reponame/actions"
    echo "  2. 点击 'Build Android APK'"
    echo "  3. 点击 'Run workflow'"
    echo "  4. 等待30分钟后下载APK"
    echo ""
else
    echo ""
    echo "❌ 上传失败，请检查:"
    echo "  - GitHub用户名是否正确"
    echo "  - Token是否有repo权限"
    echo "  - 仓库是否已创建"
fi

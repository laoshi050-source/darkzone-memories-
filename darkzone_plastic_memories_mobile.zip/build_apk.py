#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
APK打包脚本 - 跨平台支持
"""

import os
import sys
import subprocess
import platform as pf
from pathlib import Path

def check_command(cmd):
    """检查命令是否存在"""
    try:
        subprocess.run([cmd, "--version"], capture_output=True, check=True)
        return True
    except (subprocess.CalledProcessError, FileNotFoundError):
        return False

def install_dependencies():
    """安装依赖"""
    print("📦 检查依赖...")

    deps = ["buildozer", "cython", "kivy"]
    for dep in deps:
        try:
            __import__(dep)
        except ImportError:
            print(f"⬇️  安装 {dep}...")
            subprocess.run([sys.executable, "-m", "pip", "install", "--user", dep], check=True)

    print("✅ 依赖检查完成")

def check_java():
    """检查Java环境"""
    print("☕ 检查Java...")

    if check_command("javac"):
        result = subprocess.run(["javac", "-version"], capture_output=True, text=True)
        print(f"✅ Java: {result.stderr.strip()}")
        return True
    else:
        print("❌ 未找到Java编译器")
        print("
请安装JDK 17:")

        system = pf.system()
        if system == "Linux":
            print("  Ubuntu/Debian: sudo apt-get install openjdk-17-jdk")
            print("  Fedora: sudo dnf install java-17-openjdk-devel")
        elif system == "Darwin":
            print("  macOS: brew install openjdk@17")
        elif system == "Windows":
            print("  Windows: 下载 https://www.oracle.com/java/technologies/downloads/")

        return False

def build_apk():
    """构建APK"""
    print("
" + "="*50)
    print("🔨 开始打包APK...")
    print("="*50)
    print("⏳ 首次打包需要下载Android SDK/NDK")
    print("⏳ 预计耗时: 30-60分钟")
    print("="*50 + "
")

    env = os.environ.copy()

    # 设置JAVA_HOME
    if "JAVA_HOME" not in env:
        # 尝试自动检测
        java_paths = [
            "/usr/lib/jvm/java-17-openjdk-amd64",
            "/usr/lib/jvm/java-17-openjdk",
            "/usr/local/opt/openjdk@17",
        ]
        for path in java_paths:
            if os.path.exists(path):
                env["JAVA_HOME"] = path
                break

    try:
        process = subprocess.Popen(
            ["buildozer", "android", "debug"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            env=env
        )

        for line in process.stdout:
            print(line, end="")

        process.wait()

        if process.returncode == 0:
            print("
" + "="*50)
            print("🎉 APK打包成功！")
            print("="*50)

            # 查找APK文件
            bin_dir = Path("bin")
            if bin_dir.exists():
                apks = list(bin_dir.glob("*.apk"))
                if apks:
                    for apk in apks:
                        size = apk.stat().st_size
                        print(f"📱 {apk.name}")
                        print(f"📊 大小: {size/1024/1024:.1f} MB")
                        print(f"📂 路径: {apk.absolute()}")
            return True
        else:
            print("
❌ 打包失败")
            return False

    except KeyboardInterrupt:
        print("
⚠️ 用户中断")
        return False
    except Exception as e:
        print(f"
❌ 错误: {e}")
        return False

def main():
    print("🎮 暗区突围：可塑性记忆 - APK打包工具")
    print("="*50)

    # 检查依赖
    install_dependencies()

    # 检查Java
    if not check_java():
        sys.exit(1)

    # 构建APK
    if build_apk():
        print("
✅ 完成！")
    else:
        print("
❌ 打包失败，请检查错误信息")
        sys.exit(1)

if __name__ == "__main__":
    main()

#!/bin/bash
# ============================================================================
# 暗区突围：可塑性记忆 - APK一键打包脚本
# Dark Zone: Plastic Memories - APK Build Script
# ============================================================================
# 使用方法:
#   1. 确保已安装Python 3.8+
#   2. 运行此脚本: bash build_apk.sh
#   3. 等待打包完成（首次约30-60分钟）
# ============================================================================

set -e  # 遇到错误立即退出

echo "=============================================="
echo "🎮 暗区突围：可塑性记忆 - APK打包工具"
echo "=============================================="
echo ""

# 检查Python
if ! command -v python3 &> /dev/null; then
    echo "❌ 错误: 未找到Python3"
    echo "请先安装Python 3.8或更高版本"
    exit 1
fi

PYTHON_VERSION=$(python3 --version | cut -d' ' -f2)
echo "✅ Python版本: $PYTHON_VERSION"

# 检查/安装依赖
echo ""
echo "📦 检查依赖..."

# 安装buildozer
if ! command -v buildozer &> /dev/null; then
    echo "⬇️  安装Buildozer..."
    pip3 install --user buildozer cython
fi

# 安装Kivy
python3 -c "import kivy" 2>/dev/null || {
    echo "⬇️  安装Kivy..."
    pip3 install --user kivy
}

echo "✅ 依赖检查完成"

# 检查Java（Android打包需要）
echo ""
echo "☕ 检查Java环境..."
if ! command -v javac &> /dev/null; then
    echo "⚠️  未找到Java编译器"
    echo ""
    echo "请根据你的系统安装Java:"
    echo "  Ubuntu/Debian: sudo apt-get install openjdk-17-jdk"
    echo "  MacOS: brew install openjdk@17"
    echo "  Windows: 下载安装JDK 17"
    echo ""
    echo "安装完成后重新运行此脚本"
    exit 1
fi

JAVA_VERSION=$(javac -version 2>&1)
echo "✅ Java: $JAVA_VERSION"

# 设置环境变量
export JAVA_HOME=${JAVA_HOME:-$(dirname $(dirname $(readlink -f $(which javac))))}
echo "✅ JAVA_HOME: $JAVA_HOME"

# 开始打包
echo ""
echo "=============================================="
echo "🔨 开始打包APK..."
echo "=============================================="
echo "⏳ 首次打包需要下载Android SDK/NDK（约500MB-1GB）"
echo "⏳ 预计总耗时: 30-60分钟"
echo "=============================================="
echo ""

# 运行buildozer
buildozer android debug

# 检查APK是否生成
APK_PATH="bin/darkzone_memories-1.0-arm64-v8a_armeabi-v7a-debug.apk"
if [ -f "$APK_PATH" ]; then
    echo ""
    echo "=============================================="
    echo "🎉 APK打包成功！"
    echo "=============================================="
    echo "📱 文件: $APK_PATH"
    echo "📊 大小: $(du -h $APK_PATH | cut -f1)"
    echo ""
    echo "安装到手机:"
    echo "  1. 将APK发送到手机"
    echo "  2. 在手机上点击安装"
    echo "  3. 允许安装未知来源应用"
    echo ""
    echo "或使用ADB安装:"
    echo "  adb install $APK_PATH"
    echo "=============================================="
else
    echo ""
    echo "❌ APK打包失败，请检查上面的错误信息"
    echo "常见问题:"
    echo "  - 网络问题（需要下载SDK）"
    echo "  - 磁盘空间不足（需要至少5GB）"
    echo "  - 内存不足（建议8GB+）"
fi

@echo off
chcp 65001 >nul
echo ==============================================
echo 🎮 暗区突围：可塑性记忆 - APK打包工具
echo ==============================================
echo.

REM 检查Python
python --version >nul 2>&1
if errorlevel 1 (
    echo ❌ 错误: 未找到Python
    echo 请先安装Python 3.8或更高版本
    pause
    exit /b 1
)

echo ✅ Python已安装

REM 安装依赖
echo.
echo 📦 安装依赖...
pip install buildozer cython kivy

REM 检查Java
javac -version >nul 2>&1
if errorlevel 1 (
    echo ⚠️  未找到Java编译器
    echo 请下载并安装JDK 17:
    echo https://www.oracle.com/java/technologies/downloads/
    echo 安装后重新运行此脚本
    pause
    exit /b 1
)

echo ✅ Java已安装

REM 开始打包
echo.
echo ==============================================
echo 🔨 开始打包APK...
echo ==============================================
echo ⏳ 首次打包需要下载Android SDK/NDK（约500MB-1GB）
echo ⏳ 预计总耗时: 30-60分钟
echo ==============================================
echo.

buildozer android debug

REM 检查APK
if exist "bin\*.apk" (
    echo.
    echo ==============================================
    echo 🎉 APK打包成功！
    echo ==============================================
    for %%f in (bin\*.apk) do (
        echo 📱 文件: %%f
    )
    echo.
    echo 将APK发送到手机即可安装
    echo ==============================================
) else (
    echo.
    echo ❌ APK打包失败
)

pause

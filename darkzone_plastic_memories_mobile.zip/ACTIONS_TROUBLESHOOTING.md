# 备用方案：手动创建GitHub Actions

如果上传代码后Actions页面没有显示"Build Android APK"，请按以下步骤手动创建：

## 方法1: 网页手动创建（推荐）

1. 进入你的GitHub仓库
2. 点击顶部的 **Actions** 标签
3. 点击 **New workflow** 或 **set up a workflow yourself**

   ![new workflow](https://docs.github.com/assets/cb-25535/images/help/actions/new-workflow-button.png)

4. 删除默认内容，粘贴下面的代码：

```yaml
name: Build Android APK

on:
  push:
    branches: [ main, master ]
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v4
    - name: Set up Python
      uses: actions/setup-python@v5
      with:
        python-version: '3.10'
    - name: Set up Java
      uses: actions/setup-java@v4
      with:
        java-version: '17'
        distribution: 'temurin'
    - name: Install dependencies
      run: |
        sudo apt-get update
        sudo apt-get install -y libncurses5 libstdc++6 libgl1-mesa-dev libgles2-mesa-dev libarchive13 autoconf libtool pkg-config zlib1g-dev libncurses5-dev libncursesw5-dev libtinfo5 cmake libffi-dev libssl-dev automake
        pip install buildozer cython kivy pygments
    - name: Cache Buildozer
      uses: actions/cache@v3
      with:
        path: ~/.buildozer
        key: ${{ runner.os }}-buildozer-${{ hashFiles('buildozer.spec') }}
        restore-keys: |
          ${{ runner.os }}-buildozer-
    - name: Build APK
      run: |
        export JAVA_HOME=$JAVA_HOME_17_X64
        export PATH=$JAVA_HOME/bin:$PATH
        buildozer android debug
      timeout-minutes: 90
    - name: Upload APK
      uses: actions/upload-artifact@v4
      with:
        name: darkzone-memories-apk
        path: bin/*.apk
        retention-days: 30
```

5. 点击右上角的 **Start commit** → **Commit new file**
6. 文件会自动保存为 `.github/workflows/build-apk.yml`
7. 返回Actions页面，应该能看到 "Build Android APK"

## 方法2: 使用GitHub CLI

如果你有GitHub CLI：

```bash
gh workflow run build-apk.yml
```

## 方法3: 直接触发构建

如果Actions已经显示但找不到按钮：

1. 进入Actions页面
2. 点击左侧的 **Build Android APK**
3. 右侧会出现 **Run workflow** 按钮

   ![run workflow](https://docs.github.com/assets/cb-79649/images/help/actions/workflow-dispatch-from-file.png)

4. 点击按钮，选择分支，运行

## 常见问题

### Q: Actions标签完全不显示
**A**: 新仓库可能需要几分钟才能激活Actions功能，刷新页面或等待5分钟。

### Q: 显示"There are no workflow runs yet"
**A**: 这是正常的，说明文件已上传但还没运行过。点击 **Run workflow** 手动触发第一次。

### Q: 显示"Workflows aren't being run on this repository"
**A**: 检查仓库设置：
1. 点击Settings标签
2. 左侧选择Actions → General
3. 确保 "Actions permissions" 设置为 "Allow all actions and reusable workflows"

### Q: 文件上传后Actions还是空白
**A**: 可能是文件路径错误。确保文件路径是：
```
.github/workflows/build-apk.yml
```
注意：
- `.github` 前面有英文句点
- `workflows` 是复数形式
- 文件扩展名是 `.yml` 不是 `.yaml`

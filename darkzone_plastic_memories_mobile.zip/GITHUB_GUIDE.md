# GitHub Actions 自动打包指南

## 🚀 零配置自动打包（推荐）

最简单的方式：使用GitHub Actions云端自动打包，无需本地配置任何环境！

### 步骤1: 创建GitHub仓库

1. 访问 https://github.com/new
2. 创建新仓库，命名为 `darkzone-memories`
3. 选择 **Public**（免费）或 **Private**

### 步骤2: 上传代码

```bash
# 在解压后的项目目录中运行
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/你的用户名/darkzone-memories.git
git push -u origin main
```

或者直接在GitHub网页上传ZIP文件。

### 步骤3: 触发自动打包

#### 方式A: 自动触发（推荐）
每次推送代码到 `main` 分支，GitHub Actions会自动开始打包。

#### 方式B: 手动触发
1. 进入GitHub仓库页面
2. 点击 **Actions** 标签
3. 选择 **Build Android APK** 工作流
4. 点击 **Run workflow**
5. 选择是否发布到Release
6. 点击 **Run workflow**

#### 方式C: 标签触发
推送一个标签自动触发打包并发布Release：
```bash
git tag v1.0.0
git push origin v1.0.0
```

### 步骤4: 下载APK

#### 从Artifacts下载（每次构建）
1. 进入Actions页面
2. 点击最新的工作流运行
3. 滚动到 **Artifacts** 部分
4. 下载 `darkzone-memories-apk`

#### 从Release下载（正式版本）
1. 进入仓库的 **Releases** 页面
2. 找到对应的版本
3. 下载APK文件

---

## 📱 安装APK到手机

### 方法1: 直接下载
1. 用手机浏览器打开GitHub Release页面
2. 点击APK文件下载
3. 下载完成后点击安装
4. 允许"安装未知来源应用"（系统会提示）

### 方法2: 使用ADB
```bash
# 连接手机，开启USB调试
adb install darkzone-memories.apk
```

### 方法3: 使用二维码
1. 将APK上传到文件分享服务（如奶牛快传）
2. 生成下载链接的二维码
3. 手机扫描二维码下载安装

---

## ⚙️ 自定义配置

### 修改应用信息
编辑 `buildozer.spec`:
```ini
title = 你的应用名称
package.name = 你的包名
version = 1.0
```

### 修改图标
替换 `assets/icon.png`（512x512像素）

### 添加权限
编辑 `buildozer.spec`:
```ini
android.permissions = INTERNET, WRITE_EXTERNAL_STORAGE, VIBRATE
```

---

## 🔧 故障排除

### 构建失败
1. 检查Actions日志，查看具体错误
2. 常见原因：
   - 网络问题（重新运行）
   - 配置错误（检查buildozer.spec）
   - 依赖问题（更新requirements）

### APK安装失败
- 确保Android版本 >= 5.0
- 开启"允许安装未知来源应用"
- 检查APK是否完整下载

### 游戏运行卡顿
- 降低画质设置
- 关闭其他后台应用
- 确保手机有足够内存

---

## 💡 高级用法

### 自动版本号
在GitHub Actions中自动递增版本号：
```yaml
- name: Generate version
  run: |
    echo "VERSION=$(date +%Y%m%d)-${GITHUB_RUN_NUMBER}" >> $GITHUB_ENV
```

### 多渠道打包
同时打包32位和64位版本：
```ini
android.archs = arm64-v8a, armeabi-v7a
```

### 签名APK
添加签名配置到buildozer.spec：
```ini
android.signing.keystore = mykey.keystore
android.signing.alias = myalias
```

---

## 📚 相关链接

- [Kivy文档](https://kivy.org/doc/stable/)
- [Buildozer文档](https://buildozer.readthedocs.io/)
- [GitHub Actions文档](https://docs.github.com/cn/actions)

---

**提示**: GitHub Actions免费用户每月有2000分钟的构建时间，足够打包数十次APK。

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
暗区突围：可塑性记忆 - 手机端
Dark Zone: Plastic Memories - Mobile Edition
使用Kivy框架，支持Android/iOS
"""

import os
import json
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Tuple

from kivy.app import App
from kivy.uix.screenmanager import ScreenManager, Screen, SlideTransition
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.widget import Widget
from kivy.uix.popup import Popup
from kivy.graphics import Color, Rectangle, RoundedRectangle, Ellipse
from kivy.core.window import Window
from kivy.clock import Clock
from kivy.properties import StringProperty, ListProperty, BooleanProperty
from kivy.animation import Animation
from kivy.metrics import dp, sp
from kivy.utils import platform

# 手机适配
Window.clearcolor = (0.05, 0.05, 0.08, 1)
if platform not in ('android', 'ios'):
    Window.size = (dp(360), dp(640))

# ============== 数据类 ==============
@dataclass
class Character:
    name: str
    name_cn: str
    color: Tuple[float, float, float]
    voice_type: str

@dataclass
class DialogueLine:
    character: Optional[str]
    text: str
    emotion: str = "normal"
    background: str = "default"
    choices: List[Dict] = field(default_factory=list)

@dataclass
class GameFlags:
    affection_aila: int = 0
    current_route: str = "common"
    key_events: List[str] = field(default_factory=list)

# ============== 游戏数据 ==============
CHARACTERS = {
    "aila": Character("Aila", "艾拉", (1.0, 0.71, 0.76), "aila"),
    "si": Character("Si", "司", (0.39, 0.59, 1.0), "si"),
    "kazuki": Character("Kazuki", "香月", (0.78, 0.39, 0.78), "kazuki"),
    "joel": Character("Joel", "乔尔", (0.39, 0.78, 0.39), "joel"),
}

BG_COLORS = {
    "war_torn_city": [(0.24, 0.16, 0.16), (0.12, 0.08, 0.08)],
    "blackgold_office": [(0.16, 0.16, 0.24), (0.08, 0.08, 0.16)],
    "rest_room": [(0.2, 0.2, 0.2), (0.12, 0.12, 0.12)],
    "city_street": [(0.24, 0.24, 0.27), (0.16, 0.16, 0.2)],
    "abandoned_park": [(0.2, 0.24, 0.2), (0.12, 0.16, 0.12)],
    "ferris_wheel": [(0.31, 0.24, 0.31), (0.24, 0.16, 0.24)],
    "recovery_room": [(0.24, 0.24, 0.31), (0.16, 0.16, 0.24)],
    "ending": [(0.16, 0.16, 0.16), (0.08, 0.08, 0.08)],
}

# ============== 场景管理器 ==============
class SceneManager:
    def __init__(self):
        self.scenes = {}
        self.load_scenes()

    def load_scenes(self):
        # 序章
        self.scenes["prologue"] = [
            DialogueLine(None, "2045年，卡莫纳战区。\n战争已经结束，但留下的创伤远未愈合。", "normal", "war_torn_city"),
            DialogueLine(None, "在这个世界里，战术人形（T-Doll）被广泛应用于军事和民事领域。\n她们拥有与人类无异的情感，但寿命只有短短的九年零四个月。", "normal", "war_torn_city"),
            DialogueLine(None, "当寿命走到尽头，记忆开始崩溃，她们就会变成危险的'徘徊者'。", "normal", "war_torn_city"),
            DialogueLine(None, "因此，需要有人将她们在完全崩溃前回收...", "normal", "war_torn_city"),
            DialogueLine(None, "这就是终端服务部的工作。", "normal", "blackgold_office"),
        ]

        # 第一章
        self.scenes["chapter1_start"] = [
            DialogueLine(None, "你是一名刚加入黑金国际的新人特遣队员——司。", "normal", "blackgold_office"),
            DialogueLine(None, "今天是你第一次报到...", "normal", "blackgold_office"),
            DialogueLine("joel", "新人，欢迎来到终端服务部。我是乔尔·加里森，你的教官。", "normal", "blackgold_office"),
            DialogueLine("si", "（终端服务部...听说这是负责回收报废人形的部门。）", "thinking", "blackgold_office"),
            DialogueLine("joel", "别摆出那副表情。这工作虽然不受重视，但很重要。\n那些人形在寿命到期前如果不回收，记忆会崩溃，变成危险的'徘徊者'。", "serious", "blackgold_office"),
            DialogueLine("joel", "你的搭档已经在等你了。进去吧，她在3号休息室。", "normal", "blackgold_office"),
            DialogueLine(None, "司推开了3号休息室的门...", "normal", "rest_room"),
            DialogueLine("aila", "Error... 没听清楚，请再说一遍。", "confused", "rest_room"),
            DialogueLine(None, "窗边的少女转过身来。淡紫色的长发，赤色的眼眸...", "normal", "rest_room"),
            DialogueLine("aila", "啊... 你就是新搭档？我是艾拉，负责...端茶倒水的工作。", "shy", "rest_room"),
            DialogueLine("si", "（她看起来和普通人没什么两样...这就是战术人形吗？）", "surprised", "rest_room"),
            DialogueLine("si", "我是司，以后请多关照。", "smile", "rest_room"),
            DialogueLine("aila", "嗯...请多关照。", "normal", "rest_room",
                choices=[
                    {"text": "你看起来有点紧张，没事吧？", "affection": 5, "flag": "caring", "next": "chapter1_caring"},
                    {"text": "端茶倒水？你不是战斗人形吗？", "affection": -2, "flag": "curious", "next": "chapter1_curious"},
                    {"text": "（沉默地伸出手）", "affection": 0, "flag": "silent", "next": "chapter1_silent"}
                ]
            ),
        ]

        self.scenes["chapter1_caring"] = [
            DialogueLine("aila", "诶？啊...我没事。只是有点...不习惯和新搭档相处。", "surprised", "rest_room"),
            DialogueLine("aila", "之前的搭档...已经离开了。", "sad", "rest_room"),
            DialogueLine("si", "（她说的'离开'，是指被回收了吗...）", "thinking", "rest_room"),
            DialogueLine("si", "别担心，我会努力不拖你后腿的。", "smile", "rest_room"),
            DialogueLine("aila", "...谢谢。", "smile", "rest_room"),
        ]

        self.scenes["chapter1_curious"] = [
            DialogueLine("aila", "...我以前是战斗人形。但因为某些原因，现在只能做后勤工作了。", "sad", "rest_room"),
            DialogueLine("aila", "而且...我的寿命也快到了，不适合再上战场。", "bitter_smile", "rest_room"),
            DialogueLine("si", "寿命？", "confused", "rest_room"),
            DialogueLine("aila", "战术人形的寿命只有九年零四个月。\n我已经...还剩不到三个月了。", "normal", "rest_room"),
            DialogueLine("si", "（三个月...这么短吗？）", "shocked", "rest_room"),
        ]

        self.scenes["chapter1_silent"] = [
            DialogueLine("aila", "...", "confused", "rest_room"),
            DialogueLine("aila", "（握住了我的手）\n...你的手很温暖呢。", "smile", "rest_room"),
            DialogueLine("si", "（她虽然笑着，但眼神中似乎藏着什么...）", "thinking", "rest_room"),
        ]

        self.scenes["chapter1_common"] = [
            DialogueLine("kazuki", "艾拉，新人报到完了吗？", "normal", "rest_room"),
            DialogueLine("aila", "香月前辈...", "surprised", "rest_room"),
            DialogueLine(None, "一位紫发女性走了进来。她的目光锐利，身上带着久经沙场的气息。", "normal", "rest_room"),
            DialogueLine("kazuki", "我是桑乃实香月，艾拉的前搭档。既然你来了，我有话要告诉你。", "serious", "rest_room"),
            DialogueLine("kazuki", "艾拉的时间不多了。作为她的搭档，你要好好陪她走完最后的路。", "serious", "rest_room"),
            DialogueLine("si", "最后的路...是什么意思？", "confused", "rest_room"),
            DialogueLine("kazuki", "她的寿命只剩三个月。之后...就要被回收。\n回收意味着记忆全部清除，人格重置。", "sad", "rest_room"),
            DialogueLine("kazuki", "所以，不要创造太多回忆。\n离别的时候...越深的羁绊只会带来越深的痛苦。", "bitter", "rest_room"),
            DialogueLine("aila", "香月前辈...", "sad", "rest_room"),
            DialogueLine(None, "香月转身离开了。房间里只剩下沉默。", "normal", "rest_room"),
            DialogueLine("si", "（三个月吗...如果从一开始就知道结局，我该如何面对？）", "thinking", "rest_room",
                choices=[
                    {"text": "即使只有三个月，我也想创造美好的回忆", "affection": 10, "flag": "determined", "route": "true_end", "next": "chapter2_daily"},
                    {"text": "香月说得对，还是保持距离比较好", "affection": -5, "flag": "distant", "route": "bad_end", "next": "chapter2_daily"},
                    {"text": "我会尊重艾拉的选择", "affection": 3, "flag": "respect", "route": "normal_end", "next": "chapter2_daily"}
                ]
            ),
        ]

        self.scenes["chapter2_daily"] = [
            DialogueLine(None, "接下来的日子里，司和艾拉一起执行任务，回收那些寿命到期的人形。", "normal", "city_street"),
            DialogueLine(None, "每一次回收，都是一次离别。\n看着那些曾经拥有感情的人形被重置，司渐渐理解了这份工作的沉重。", "normal", "city_street"),
            DialogueLine("aila", "愿你有朝一日，能与珍爱之人再次相逢。", "sad", "city_street"),
            DialogueLine(None, "艾拉每次回收后都会轻声说出这句话。\n这是她对被回收人形的祝福，也是对自己的安慰。", "normal", "city_street"),
            DialogueLine("si", "艾拉...你害怕吗？", "worried", "city_street"),
            DialogueLine("aila", "害怕？", "confused", "city_street"),
            DialogueLine("si", "害怕被回收...害怕失去记忆，失去自我。", "sad", "city_street"),
            DialogueLine("aila", "...当然害怕。", "sad", "city_street"),
            DialogueLine("aila", "但是，如果因为害怕就不去创造回忆，\n那这最后的时间不就白白浪费了吗？", "smile", "city_street"),
            DialogueLine("aila", "司...能陪我去一个地方吗？", "shy", "city_street",
                choices=[
                    {"text": "当然，去哪里？", "affection": 5, "flag": "agree", "next": "chapter2_park"},
                    {"text": "现在还在任务中...", "affection": -3, "flag": "hesitate", "next": "chapter2_park"},
                ]
            ),
        ]

        self.scenes["chapter2_park"] = [
            DialogueLine(None, "艾拉带司来到了废弃的游乐园。\n这里曾是卡莫纳最繁华的地方，如今只剩下断壁残垣。", "normal", "abandoned_park"),
            DialogueLine("aila", "这里...是我和前任搭档最后一次来的地方。", "nostalgic", "abandoned_park"),
            DialogueLine("aila", "她说，即使在最黑暗的时代，也要寻找光明。", "smile", "abandoned_park"),
            DialogueLine("aila", "司，能陪我坐一次摩天轮吗？", "shy", "abandoned_park"),
            DialogueLine(None, "摩天轮的座舱缓缓上升。\n从高处俯瞰，战区的废墟尽收眼底，但夕阳的余晖却给一切镀上了金色。", "normal", "ferris_wheel"),
            DialogueLine("aila", "好美...", "amazed", "ferris_wheel"),
            DialogueLine("aila", "司，你知道吗？人形的记忆是可以备份的。\n但情感...却无法复制。", "sad", "ferris_wheel"),
            DialogueLine("aila", "所以，即使以后我被重置了，\n现在这份感动也会永远留在我心中。", "smile", "ferris_wheel"),
            DialogueLine("si", "艾拉...", "sad", "ferris_wheel"),
            DialogueLine("aila", "谢谢你，司。\n在最后的时间里，能遇到你，我真的很幸福。", "crying_smile", "ferris_wheel"),
        ]

        self.scenes["ending_true"] = [
            DialogueLine(None, "三个月的时间转瞬即逝。", "normal", "blackgold_office"),
            DialogueLine(None, "艾拉的回收日到了。", "normal", "blackgold_office"),
            DialogueLine("joel", "司...你确定要亲自执行吗？", "worried", "blackgold_office"),
            DialogueLine("si", "是的。这是我对她最后的责任。", "determined", "blackgold_office"),
            DialogueLine(None, "艾拉穿着白色的连衣裙，安静地坐在回收椅上。", "normal", "recovery_room"),
            DialogueLine("aila", "司，不要哭。", "smile", "recovery_room"),
            DialogueLine("aila", "这三个月，是我一生中最幸福的时光。\n即使记忆会被重置，这份感情也会以某种形式留存下来。", "smile", "recovery_room"),
            DialogueLine("si", "艾拉...我...", "crying", "recovery_room"),
            DialogueLine("aila", "时光流转，愿你与珍爱之人能再次相逢。", "blessing", "recovery_room"),
            DialogueLine(None, "艾拉闭上了眼睛，嘴角带着微笑。\n回收程序启动，她的记忆渐渐消散...", "normal", "recovery_room"),
            DialogueLine(None, "一年后，司回到了终端服务部。", "normal", "blackgold_office"),
            DialogueLine(None, "新的搭档走了进来——淡紫色的长发，赤色的眼眸。", "normal", "blackgold_office"),
            DialogueLine("aila", "你好，我是艾拉。请多多指教。", "normal", "blackgold_office"),
            DialogueLine("si", "（虽然记忆不在了，但我会重新创造属于我们的回忆。）", "smile", "blackgold_office"),
            DialogueLine(None, "【真结局：时光流转，愿与珍爱之人再次相逢】", "normal", "ending"),
        ]

        self.scenes["ending_bad"] = [
            DialogueLine(None, "司选择了保持距离。", "normal", "blackgold_office"),
            DialogueLine(None, "艾拉在沉默中迎来了回收日。\n没有告别，没有眼泪，就像从未存在过一样。", "normal", "recovery_room"),
            DialogueLine(None, "司继续着他的工作，但心中始终有一个空洞。\n他明白了香月的话——逃避并不能减少痛苦，只会留下遗憾。", "normal", "blackgold_office"),
            DialogueLine(None, "【结局：错过的羁绊】", "normal", "ending"),
        ]

        self.scenes["ending_normal"] = [
            DialogueLine(None, "司尊重了艾拉的选择。", "normal", "blackgold_office"),
            DialogueLine(None, "他们一起度过了平静的三个月。\n没有波澜壮阔的冒险，只有日常中的点滴温暖。", "normal", "city_street"),
            DialogueLine(None, "回收日那天，艾拉微笑着离开了。\n司带着回忆继续前行，成为了更好的特遣队员。", "normal", "recovery_room"),
            DialogueLine(None, "【结局：珍藏的回忆】", "normal", "ending"),
        ]

# ============== UI组件 ==============
class BackgroundWidget(Widget):
    def __init__(self, bg_name="default", **kwargs):
        super().__init__(**kwargs)
        self.bg_name = bg_name
        self.bind(pos=self.update_bg, size=self.update_bg)
        self.update_bg()

    def update_bg(self, *args):
        self.canvas.clear()
        colors = BG_COLORS.get(self.bg_name, [(0.16, 0.16, 0.2), (0.08, 0.08, 0.12)])
        with self.canvas:
            for i in range(int(self.height)):
                ratio = i / self.height
                r = colors[0][0] * (1 - ratio) + colors[1][0] * ratio
                g = colors[0][1] * (1 - ratio) + colors[1][1] * ratio
                b = colors[0][2] * (1 - ratio) + colors[1][2] * ratio
                Color(r, g, b, 1)
                Rectangle(pos=(self.x, self.y + i), size=(self.width, 1))

class CharacterSprite(Widget):
    def __init__(self, char_id, emotion="normal", **kwargs):
        super().__init__(**kwargs)
        self.char_id = char_id
        self.emotion = emotion
        self.bind(pos=self.draw_sprite, size=self.draw_sprite)
        self.draw_sprite()

    def draw_sprite(self, *args):
        self.canvas.clear()
        char = CHARACTERS.get(self.char_id)
        if not char:
            return
        with self.canvas:
            Color(*char.color, 0.9)
            Ellipse(pos=(self.x + self.width*0.1, self.y), size=(self.width*0.8, self.height*0.7))
            Color(1, 0.86, 0.78, 1)
            Ellipse(pos=(self.x + self.width*0.2, self.y + self.height*0.55), size=(self.width*0.6, self.height*0.35))
            eye_colors = {"normal": (0.39, 0.2, 0.2), "happy": (0.39, 0.2, 0.2), "sad": (0.2, 0.2, 0.39)}
            eye_color = eye_colors.get(self.emotion, (0.39, 0.2, 0.2))
            Color(*eye_color, 1)
            Ellipse(pos=(self.x + self.width*0.3, self.y + self.height*0.7), size=(self.width*0.12, self.height*0.08))
            Ellipse(pos=(self.x + self.width*0.58, self.y + self.height*0.7), size=(self.width*0.12, self.height*0.08))
            if self.char_id == "aila":
                Color(0.78, 0.71, 0.86, 0.9)
                Ellipse(pos=(self.x + self.width*0.15, self.y + self.height*0.75), size=(self.width*0.7, self.height*0.25))
            elif self.char_id == "kazuki":
                Color(0.71, 0.47, 0.78, 0.9)
                Ellipse(pos=(self.x + self.width*0.2, self.y + self.height*0.78), size=(self.width*0.6, self.height*0.2))

class DialogueBox(FloatLayout):
    speaker_name = StringProperty("")
    dialogue_text = StringProperty("")
    speaker_color = ListProperty([1, 1, 1, 1])

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.build_ui()

    def build_ui(self):
        with self.canvas.before:
            Color(0.08, 0.08, 0.12, 0.95)
            self.bg = RoundedRectangle(pos=self.pos, size=self.size, radius=[dp(15)])
        self.bind(pos=self.update_bg, size=self.update_bg)

        self.name_label = Label(
            text=self.speaker_name, font_size=sp(16), bold=True,
            color=self.speaker_color, size_hint=(None, None),
            size=(dp(120), dp(30)), pos_hint={'x': 0.05, 'top': 0.95}
        )
        self.bind(speaker_name=self.name_label.setter('text'))
        self.bind(speaker_color=self.name_label.setter('color'))
        self.add_widget(self.name_label)

        self.text_label = Label(
            text=self.dialogue_text, font_size=sp(14), color=(1, 1, 1, 1),
            size_hint=(0.9, 0.7), pos_hint={'center_x': 0.5, 'y': 0.1},
            text_size=(None, None), halign='left', valign='top'
        )
        self.bind(dialogue_text=self.update_text)
        self.add_widget(self.text_label)

        self.continue_label = Label(
            text="▼", font_size=sp(20), color=(1, 1, 1, 0.8),
            size_hint=(None, None), size=(dp(30), dp(30)),
            pos_hint={'right': 0.95, 'y': 0.05}
        )
        self.add_widget(self.continue_label)
        anim = Animation(opacity=0.3, duration=0.5) + Animation(opacity=1, duration=0.5)
        anim.repeat = True
        anim.start(self.continue_label)

    def update_bg(self, *args):
        self.bg.pos = self.pos
        self.bg.size = self.size
        self.text_label.text_size = (self.width * 0.9, None)

    def update_text(self, instance, value):
        self.text_label.text = value

# ============== 游戏屏幕 ==============
class TitleScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.build_ui()

    def build_ui(self):
        layout = FloatLayout()
        bg = BackgroundWidget(bg_name="war_torn_city", size_hint=(1, 1))
        layout.add_widget(bg)

        title = Label(
            text="暗区突围
可塑性记忆", font_size=sp(32), bold=True,
            color=(1, 0.78, 0.78, 1), size_hint=(None, None),
            size=(dp(300), dp(100)), pos_hint={'center_x': 0.5, 'top': 0.75},
            halign='center'
        )
        layout.add_widget(title)

        subtitle = Label(
            text="Dark Zone: Plastic Memories", font_size=sp(14),
            color=(0.8, 0.8, 0.8, 1), size_hint=(None, None),
            size=(dp(300), dp(30)), pos_hint={'center_x': 0.5, 'top': 0.6}
        )
        layout.add_widget(subtitle)

        btn_layout = BoxLayout(
            orientation='vertical', spacing=dp(10),
            size_hint=(0.7, None), height=dp(200),
            pos_hint={'center_x': 0.5, 'y': 0.15}
        )

        btn_layout.add_widget(Button(
            text="开始游戏", font_size=sp(16),
            background_color=(0.3, 0.3, 0.5, 0.9),
            on_press=self.start_game
        ))
        btn_layout.add_widget(Button(
            text="继续游戏", font_size=sp(16),
            background_color=(0.3, 0.3, 0.5, 0.9),
            on_press=self.load_game
        ))
        btn_layout.add_widget(Button(
            text="设置", font_size=sp(16),
            background_color=(0.3, 0.3, 0.5, 0.9),
            on_press=self.open_settings
        ))

        layout.add_widget(btn_layout)
        self.add_widget(layout)

    def start_game(self, instance):
        self.manager.get_screen('game').start_new_game()
        self.manager.current = 'game'

    def load_game(self, instance):
        game_screen = self.manager.get_screen('game')
        if game_screen.load_game():
            self.manager.current = 'game'

    def open_settings(self, instance):
        pass

class GameScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.scene_manager = SceneManager()
        self.flags = GameFlags()
        self.current_scene = None
        self.current_line_idx = 0
        self.text_progress = 0
        self.text_speed = 2
        self.is_typing = False
        self.current_line = None
        self.build_ui()
        Clock.schedule_interval(self.update, 1/60)

    def build_ui(self):
        self.layout = FloatLayout()

        self.bg_widget = BackgroundWidget(bg_name="war_torn_city", size_hint=(1, 1))
        self.layout.add_widget(self.bg_widget)

        self.char_widget = CharacterSprite(
            "aila", size_hint=(None, None),
            size=(dp(200), dp(350)), pos_hint={'right': 0.95, 'y': 0.25}
        )
        self.layout.add_widget(self.char_widget)

        self.dialogue_box = DialogueBox(
            size_hint=(0.95, 0.22), pos_hint={'center_x': 0.5, 'y': 0.02}
        )
        self.layout.add_widget(self.dialogue_box)

        self.choice_layout = BoxLayout(
            orientation='vertical', spacing=dp(10), padding=dp(20),
            size_hint=(0.9, 0.4), pos_hint={'center_x': 0.5, 'center_y': 0.5},
            opacity=0
        )
        self.layout.add_widget(self.choice_layout)

        menu_btn = Button(
            text="☰", font_size=sp(20), size_hint=(None, None),
            size=(dp(40), dp(40)), pos_hint={'x': 0.02, 'top': 0.98},
            background_color=(0.2, 0.2, 0.3, 0.7)
        )
        menu_btn.bind(on_press=self.show_menu)
        self.layout.add_widget(menu_btn)

        self.affection_label = Label(
            text="♥ 0", font_size=sp(12), color=(1, 0.5, 0.5, 1),
            size_hint=(None, None), size=(dp(60), dp(30)),
            pos_hint={'right': 0.98, 'top': 0.98}
        )
        self.layout.add_widget(self.affection_label)

        self.add_widget(self.layout)
        self.layout.bind(on_touch_down=self.on_screen_touch)

    def start_new_game(self):
        self.flags = GameFlags()
        self.current_scene = "prologue"
        self.current_line_idx = 0
        self.load_line()

    def load_line(self):
        if self.current_scene not in self.scene_manager.scenes:
            return
        scene = self.scene_manager.scenes[self.current_scene]
        if self.current_line_idx >= len(scene):
            self.determine_next_scene()
            return

        self.current_line = scene[self.current_line_idx]
        self.text_progress = 0
        self.is_typing = True

        self.bg_widget.bg_name = self.current_line.background
        self.bg_widget.update_bg()

        if self.current_line.character:
            self.char_widget.char_id = self.current_line.character
            self.char_widget.emotion = self.current_line.emotion
            self.char_widget.draw_sprite()
            self.char_widget.opacity = 1
            char = CHARACTERS.get(self.current_line.character)
            if char:
                self.dialogue_box.speaker_name = char.name_cn
                self.dialogue_box.speaker_color = list(char.color) + [1]
        else:
            self.char_widget.opacity = 0
            self.dialogue_box.speaker_name = "旁白"
            self.dialogue_box.speaker_color = [0.5, 0.5, 0.5, 1]

        self.choice_layout.opacity = 0
        self.choice_layout.clear_widgets()

    def update(self, dt):
        if self.is_typing and self.current_line:
            self.text_progress += self.text_speed
            full_text = self.current_line.text
            if self.text_progress >= len(full_text):
                self.text_progress = len(full_text)
                self.is_typing = False
                if self.current_line.choices:
                    self.show_choices(self.current_line.choices)
            display_text = full_text[:int(self.text_progress)]
            self.dialogue_box.dialogue_text = display_text

    def on_screen_touch(self, instance, touch):
        if self.choice_layout.opacity > 0:
            return
        if self.is_typing:
            self.text_progress = len(self.current_line.text)
        else:
            self.current_line_idx += 1
            self.load_line()

    def show_choices(self, choices):
        self.choice_layout.opacity = 1
        self.choice_layout.clear_widgets()
        for choice in choices:
            btn = Button(
                text=choice["text"], font_size=sp(14),
                background_color=(0.16, 0.16, 0.24, 0.9),
                background_normal='', color=(1, 1, 1, 1),
                size_hint_y=None, height=dp(50)
            )
            btn.bind(on_press=lambda inst, c=choice: self.on_choice(c))
            self.choice_layout.add_widget(btn)

    def on_choice(self, choice):
        if "affection" in choice:
            self.flags.affection_aila += choice["affection"]
            self.affection_label.text = f"♥ {self.flags.affection_aila}"
        if "flag" in choice:
            self.flags.key_events.append(choice["flag"])
        if "route" in choice:
            self.flags.current_route = choice["route"]

        next_scene = choice.get("next", "")
        if next_scene:
            if self.current_scene == "chapter1_start":
                self.current_scene = next_scene
                self.current_line_idx = 0
                self.load_line()
            elif self.current_scene in ["chapter1_caring", "chapter1_curious", "chapter1_silent"]:
                self.current_scene = "chapter1_common"
                self.current_line_idx = 0
                self.load_line()
            elif self.current_scene == "chapter1_common":
                self.current_scene = next_scene
                self.current_line_idx = 0
                self.load_line()
            elif self.current_scene == "chapter2_daily":
                self.current_scene = next_scene
                self.current_line_idx = 0
                self.load_line()
            elif self.current_scene == "chapter2_park":
                self.determine_ending()

    def determine_next_scene(self):
        transitions = {
            "prologue": "chapter1_start",
            "chapter1_caring": "chapter1_common",
            "chapter1_curious": "chapter1_common",
            "chapter1_silent": "chapter1_common",
            "chapter1_common": "chapter2_daily",
            "chapter2_daily": "chapter2_park",
        }
        next_scene = transitions.get(self.current_scene)
        if self.current_scene == "chapter2_park":
            self.determine_ending()
        elif next_scene:
            self.current_scene = next_scene
            self.current_line_idx = 0
            self.load_line()

    def determine_ending(self):
        if self.flags.affection_aila >= 15:
            self.current_scene = "ending_true"
        elif self.flags.affection_aila >= 5:
            self.current_scene = "ending_normal"
        else:
            self.current_scene = "ending_bad"
        self.current_line_idx = 0
        self.load_line()

    def show_menu(self, instance):
        content = BoxLayout(orientation='vertical', spacing=dp(10), padding=dp(20))
        content.add_widget(Button(text="继续", on_press=lambda x: self.popup.dismiss()))
        content.add_widget(Button(text="保存", on_press=lambda x: self.save_game()))
        content.add_widget(Button(text="标题画面", on_press=lambda x: self.goto_title()))
        self.popup = Popup(title="菜单", content=content, size_hint=(0.8, 0.5))
        self.popup.open()

    def save_game(self):
        save_data = {
            "scene": self.current_scene,
            "line": self.current_line_idx,
            "flags": {
                "affection_aila": self.flags.affection_aila,
                "current_route": self.flags.current_route,
                "key_events": self.flags.key_events
            }
        }
        save_dir = os.path.join(os.path.dirname(__file__), 'saves')
        os.makedirs(save_dir, exist_ok=True)
        with open(os.path.join(save_dir, 'save_1.json'), 'w', encoding='utf-8') as f:
            json.dump(save_data, f, ensure_ascii=False)
        if hasattr(self, 'popup'):
            self.popup.dismiss()

    def load_game(self):
        save_path = os.path.join(os.path.dirname(__file__), 'saves', 'save_1.json')
        if not os.path.exists(save_path):
            return False
        with open(save_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        self.current_scene = data.get("scene", "prologue")
        self.current_line_idx = data.get("line", 0)
        flags = data.get("flags", {})
        self.flags.affection_aila = flags.get("affection_aila", 0)
        self.flags.current_route = flags.get("current_route", "common")
        self.flags.key_events = flags.get("key_events", [])
        self.load_line()
        return True

    def goto_title(self):
        if hasattr(self, 'popup'):
            self.popup.dismiss()
        self.manager.current = 'title'

# ============== 应用主类 ==============
class DarkZoneApp(App):
    def build(self):
        Window.clearcolor = (0.05, 0.05, 0.08, 1)
        sm = ScreenManager(transition=SlideTransition())
        sm.add_widget(TitleScreen(name='title'))
        sm.add_widget(GameScreen(name='game'))
        return sm

if __name__ == '__main__':
    DarkZoneApp().run()
